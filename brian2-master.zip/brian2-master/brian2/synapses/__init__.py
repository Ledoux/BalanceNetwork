'''
Package providing synapse support.
'''

from .synapses import *