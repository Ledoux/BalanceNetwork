{% extends 'common_group.cpp' %}
{# USES_VARIABLES { N } #}
{% block extra_headers %}
#include <stdint.h>
#include "synapses_classes.h"
{% endblock %}
