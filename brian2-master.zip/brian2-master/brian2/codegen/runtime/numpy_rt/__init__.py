'''
Numpy runtime implementation.

Preferences
--------------------
.. document_brian_prefs:: codegen.runtime.numpy
'''

from .numpy_rt import *
