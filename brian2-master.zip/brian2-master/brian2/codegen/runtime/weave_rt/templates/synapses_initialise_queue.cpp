{% macro main() %}
{% endmacro %}

{% macro support_code() %}
{% endmacro %}

{% macro python_pre() %}
_owner.initialise_queue()
{% endmacro %}
