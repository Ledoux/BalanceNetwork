{% macro main() %}
{% endmacro %}

{% macro support_code() %}
{% endmacro %}

{% macro python_pre() %}
_owner.push_spikes()
{% endmacro %}
