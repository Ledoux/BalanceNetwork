Brian 2 documentation
=====================

Contents:

.. toctree::
   :maxdepth: 2
   :titlesonly:

   introduction/index
   resources/tutorials/index
   user/index
   advanced/index

.. toctree::
   :maxdepth: 1
   :titlesonly:

   examples/index
   Reference documentation <reference/brian2>
   developer/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
