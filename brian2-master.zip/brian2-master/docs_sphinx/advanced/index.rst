Advanced guide
==============

This section has additional information on details not covered in the
:doc:`../user/index`.

.. toctree::
   :maxdepth: 2
   
   preferences
   namespaces
   refractoriness
   scheduling
   state_update
   how_brian_works
   interface

