User's guide
=================

.. toctree::
   :maxdepth: 2
   
   import
   units
   models
   equations
   refractoriness
   synapses
   input
   recording
   running
   computation
   functions
   devices
   brian1hears_bridge
   multicompartmental
